package ru.krus.taxiapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class PassengerSignInActivity extends AppCompatActivity {

    private static final String TAG = "PassengerSignInActivity";

    private TextInputLayout textInputEmailPassenger;
    private TextInputLayout textInputNamePassenger;
    private TextInputLayout textInputPasswordPassenger;
    private TextInputLayout textInputConfirmPasswordPassenger;

    private Button loginSignUpButtonPassenger;
    private TextView toogleLoginSignUpTextViewPassenger;

    private boolean isLoginModeActive;

    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_sign_in);
        textInputEmailPassenger = findViewById(R.id.textInputEmailPassenger);
        textInputNamePassenger = findViewById(R.id.textInputNamePassenger);
        textInputPasswordPassenger = findViewById(R.id.textInputPasswordPassenger);
        textInputConfirmPasswordPassenger = findViewById(R.id.textInputConfirmPasswordPassenger);

        loginSignUpButtonPassenger = findViewById(R.id.loginSignUpButtonPassenger);
        toogleLoginSignUpTextViewPassenger = findViewById(R.id.toogleLoginTextViewPassenger);

        auth = FirebaseAuth.getInstance();
    }

    private boolean validateEmail(){
        String emailInputPassenger = textInputEmailPassenger.getEditText().getText().toString().trim();
        if (emailInputPassenger.isEmpty()){
            textInputEmailPassenger.setError("Please input your email");
            return false;
        }
        else {
            textInputEmailPassenger.setError("");
            return true;
        }
    }

    private boolean validateName(){
        String nameInputPassenger = textInputNamePassenger.getEditText().getText().toString().trim();
        if (nameInputPassenger.isEmpty()){
            textInputNamePassenger.setError("Please input your email");
            return false;
        } else if (nameInputPassenger.length() > 15){
            textInputNamePassenger.setError("Name length have to be less than 15 characters");
            return false;
        }
        else {
            textInputNamePassenger.setError("");
            return true;
        }
    }

    private boolean validatePassword(){
        String passwordInputPassenger = textInputPasswordPassenger.getEditText().getText().toString().trim();
        if (passwordInputPassenger.isEmpty()){
            textInputPasswordPassenger.setError("Please input your email");
            return false;
        } else if (passwordInputPassenger.length() < 7){
            textInputPasswordPassenger.setError("Name length have to be more than 6 characters");
            return false;
        }
        else {
            textInputPasswordPassenger.setError("");
            return true;
        }
    }

    private boolean validateConfirmPassword(){
        String passwordInputPassenger = textInputPasswordPassenger.getEditText().getText().toString().trim();
        String confirmPasswordInputPassenger = textInputConfirmPasswordPassenger.getEditText().getText().toString().trim();
        if (!passwordInputPassenger.equals(confirmPasswordInputPassenger)){
            textInputPasswordPassenger.setError("Password have to match");
            return false;
        }
        else {
            textInputPasswordPassenger.setError("");
            return true;
        }
    }

    public void LoginSignUpUserPassenger(View view) {
        if (!validateEmail() | !validateName() | !validatePassword()){
            return;
        }
        if (isLoginModeActive){
            auth.signInWithEmailAndPassword(textInputEmailPassenger.getEditText().getText().toString().trim(), textInputPasswordPassenger.getEditText().getText().toString().trim())
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                Log.d(TAG, "signInWithEmail:success");
                                FirebaseUser user = auth.getCurrentUser();
                                //updateUI(user);
                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w(TAG, "signInWithEmail:failure", task.getException());
                                Toast.makeText(PassengerSignInActivity.this, "Authentication failed.",
                                        Toast.LENGTH_SHORT).show();
                                //updateUI(null);
                                // ...
                            }

                            // ...
                        }
                    });
        } else {
            if (!validateEmail() | !validateName() | !validatePassword() | !validateConfirmPassword()){
                return;
            }
            auth.createUserWithEmailAndPassword(textInputEmailPassenger.getEditText().getText().toString().trim(), textInputPasswordPassenger.getEditText().getText().toString().trim())
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                Log.d(TAG, "createUserWithEmail:success");
                                FirebaseUser user = auth.getCurrentUser();
                                // updateUI(user);
                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                Toast.makeText(PassengerSignInActivity.this, "Authentication failed.",
                                        Toast.LENGTH_SHORT).show();
                                //updateUI(null);
                            }

                            // ...
                        }
                    });
        }
    }

    public void toggleLoginSinUpPassenger(View view) {

        if (isLoginModeActive){
            isLoginModeActive = false;
            loginSignUpButtonPassenger.setText("Sign Up");
            toogleLoginSignUpTextViewPassenger.setText("Or log in");
            textInputConfirmPasswordPassenger.setVisibility(View.VISIBLE);
        } else {
            isLoginModeActive = true;
            loginSignUpButtonPassenger.setText("Log In");
            toogleLoginSignUpTextViewPassenger.setText("Or sign up");
            textInputConfirmPasswordPassenger.setVisibility(View.GONE);
        }
    }
}
